document.getElementById("calculationType").addEventListener("change", function() {
    let type = this.value;
    document.getElementById("interestSection").style.display = (type === "interest") ? "block" : "none";
    document.getElementById("percentageSection").style.display = (type === "percentage") ? "block" : "none";
});

function calculate() {
    let type = document.getElementById("calculationType").value;
    let resultText = "";

    if (type === "interest") {
        let principal = parseFloat(document.getElementById("principal").value);
        let rate = parseFloat(document.getElementById("rate").value);
        let time = parseFloat(document.getElementById("time").value);

        if (isNaN(principal) || isNaN(rate) || isNaN(time)) {
            resultText = "الرجاء إدخال جميع القيم لحساب الفائدة.";
        } else {
            let interest = (principal * rate * time) / 100;
            resultText = `الفائدة المستحقة: ${interest.toFixed(2)}`;
        }
    } 
    
    else if (type === "percentage") {
        let total = parseFloat(document.getElementById("total").value);
        let part = parseFloat(document.getElementById("part").value);

        if (isNaN(total) || isNaN(part)) {
            resultText = "الرجاء إدخال جميع القيم لحساب النسبة المئوية.";
        } else {
            let percentage = (part / total) * 100;
            resultText = `النسبة المئوية: ${percentage.toFixed(2)}%`;
        }
    } 
    
    else {
        resultText = "يرجى اختيار نوع الحساب.";
    }

    document.getElementById("result").innerText = resultText;
}